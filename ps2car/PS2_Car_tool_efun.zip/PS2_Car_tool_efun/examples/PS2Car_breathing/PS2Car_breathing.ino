/*
 * PS2 小車 範例程式（由「PS2 控制配置台」預設設定產生）
 * 就算網頁不在了，這個檔案也能單獨看懂、直接使用。
 *
 * 【怎麼用】
 *   1. 用 Arduino IDE 開啟這個資料夾裡的 .ino（資料夾已包含所需函式庫，不用另外安裝）。
 *   2. 工具 -> 開發板：Arduino Uno；工具 -> 連接埠：選 COM 埠；按「上傳」。
 *
 * 【燈號與聲音】
 *   開機：暗紫燈約 0.4 秒（表示程式啟動），之後紅燈=戰車模式。
 *   方向鍵「下」切換成戰車（紅燈、低音嗶），方向鍵「上」切換成遙控車（綠燈、高音嗶）。
 *   手把斷線（約 0.15 秒收不到訊號）：所有馬達自動煞車，訊號恢復後繼續。
 *
 * 【預設按鍵】
 *   戰車模式：左搖桿上下=左輪、右搖桿上下=右輪；其他按鍵對應請看下方程式。
 *   想改按鍵、馬達或搖桿設定，請用「PS2 控制配置台」重新產生程式碼。
 *
 * 【這是哪一版】呼吸燈車號 1 號版：多台車放在一起時，用燈的呼吸快慢分辨。
 *   戰車=深紅~粉紅呼吸，遙控車=深綠~淺綠呼吸；顏色代表模式，呼吸快慢代表車號。
 *   手把斷線煞車時，燈改成急促閃紅。
 *   換車號不用開網頁：找到下面 BREATH_PERIOD 那一行，把數字改成：
 *     1 號 = 4000（最慢）  2 號 = 2700  3 號 = 1800  4 號 = 1200（最快）
 *   每台車要各自設定不同的號碼、各自上傳。
 */
#include "Emakefun_MotorDriver.h"
#include "RGBLed.h"
#include "Buzzer.h"
// 由 PS2 控制配置台自動產生 — 可直接貼上 Arduino IDE 取代原本的 .ino 內容

Emakefun_MotorDriver mMotorDriver = Emakefun_MotorDriver(0x60, MOTOR_DRIVER_BOARD_V5);
PS2X *ps2x;
int psFailCount = 0;  // 連續讀取失敗次數（手把斷線/太遠/沒電偵測用）
bool tankMode = true;  // 方向鍵切換：false=遙控車模式, true=戰車模式
RGBLed statusLed(A1, 1);  // 板載 RGB 燈（A1）：目前模式指示，綠=遙控車, 紅=戰車
Buzzer buzzer(A0);        // 板載蜂鳴器（A0）：切換模式時短嗶確認
const unsigned long BREATH_PERIOD = 4000;  // 呼吸燈車號 1：一輪的毫秒數，數字越小呼吸越快

int Servo1_IDLE = 75;
int Servo2_IDLE = 75;
int Servo3_IDLE = 75;
int Servo4_IDLE = 74;
int Servo5_IDLE = 74;
int Servo6_IDLE = 90;
int Servo7_IDLE = 70;
int Servo8_IDLE = 90;

Emakefun_DCMotor *RW = mMotorDriver.getMotor(M1);  // 搖桿混控驅動輪
Emakefun_DCMotor *LW = mMotorDriver.getMotor(M2);  // 搖桿混控驅動輪
Emakefun_DCMotor *RD = mMotorDriver.getMotor(M3);  // R1/R2 按鍵控制
Emakefun_DCMotor *FD = mMotorDriver.getMotor(M4);  // L1/L2 按鍵控制

Emakefun_Servo *Servo1 = mMotorDriver.getServo(1);  // 方形/圓形鍵
Emakefun_Servo *Servo2 = mMotorDriver.getServo(2);
Emakefun_Servo *Servo3 = mMotorDriver.getServo(3);  // 三角/叉叉鍵
Emakefun_Servo *Servo4 = mMotorDriver.getServo(4);  // 左搖桿X軸
Emakefun_Servo *Servo5 = mMotorDriver.getServo(7);
Emakefun_Servo *Servo6 = mMotorDriver.getServo(8);
Emakefun_Servo *Servo7 = mMotorDriver.getServo(5);
Emakefun_Servo *Servo8 = mMotorDriver.getServo(6);

void setup() {
  Serial.begin(9600);
  ps2x = mMotorDriver.getSensor(E_PS2X);
  mMotorDriver.begin(50);
  RW->setSpeed(255);
  LW->setSpeed(255);
  RD->setSpeed(255);
  FD->setSpeed(255);
  Servo1->writeServo(Servo1_IDLE);
  Servo2->writeServo(Servo2_IDLE);
  Servo3->writeServo(Servo3_IDLE);
  Servo4->writeServo(Servo4_IDLE);
  Servo5->writeServo(Servo5_IDLE);
  Servo6->writeServo(Servo6_IDLE);
  Servo7->writeServo(Servo7_IDLE);
  Servo8->writeServo(Servo8_IDLE);
  statusLed.setColor(40, 0, 40);  // 開機辨識用：不要太亮的紫燈，閃一下方便跟舊版分辨
  statusLed.show();
  delay(400);
  statusLed.setColor(255, 0, 0);  // 開機預設戰車模式=紅燈
  statusLed.show();
}

void loop() {
  static int vibrate = 0;
  bool psOk = ps2x->read_gamepad(false, vibrate);
  if (psOk) { psFailCount = 0; } else { psFailCount++; }
  if (psFailCount >= 3) {
    // 手把訊號連續讀取失敗（可能太遠/沒電/斷線）：所有馬達煞車，等訊號恢復再繼續
    RW->run(BRAKE);
    LW->run(BRAKE);
    RD->run(BRAKE);
    FD->run(BRAKE);
    statusLed.setColor(((millis() / 120) % 2) ? 255 : 0, 0, 0);  // 斷線：急促閃紅
    statusLed.show();
    return;
  }
  if (ps2x->ButtonPressed(PSB_PAD_UP) && tankMode) {
    tankMode = false;
    statusLed.setColor(0, 255, 0);  // 遙控車模式=綠燈
    statusLed.show();
    buzzer.tone(2000, 60);
  }
  if (ps2x->ButtonPressed(PSB_PAD_DOWN) && !tankMode) {
    tankMode = true;
    statusLed.setColor(255, 0, 0);  // 戰車模式=紅燈
    statusLed.show();
    buzzer.tone(1000, 60);
  }
  // 呼吸燈：戰車=深紅~粉紅，遙控車=深綠~淺綠；車號越大呼吸越快
  {
    int t = (int)((millis() % BREATH_PERIOD) * 200UL / BREATH_PERIOD);  // 0..199
    if (t > 100) t = 200 - t;                                          // 三角波 0..100..0
    if (tankMode) {
      statusLed.setColor(90 + t * 165 / 100, t * 70 / 100, t * 90 / 100);  // 深紅 -> 粉紅
    } else {
      statusLed.setColor(t * 80 / 100, 90 + t * 165 / 100, t * 60 / 100);  // 深綠 -> 淺綠
    }
    statusLed.show();
  }

  // ---- RD (R1/R2 按鍵控制) ----
  if (ps2x->Button(PSB_R1)) {
    RD->run(BACKWARD);
    RD->setSpeed(255);
  } else if (ps2x->Button(PSB_R2)) {
    RD->run(FORWARD);
    RD->setSpeed(255);
  } else {
    RD->run(BRAKE);
  }

  // ---- FD (L1/L2 按鍵控制) ----
  if (ps2x->Button(PSB_L1)) {
    FD->run(FORWARD);
    FD->setSpeed(255);
  } else if (ps2x->Button(PSB_L2)) {
    FD->run(BACKWARD);
    FD->setSpeed(120);
  } else {
    FD->run(BRAKE);
  }

  // ---- 遙控車模式／戰車模式（方向鍵即時切換）----
  // 死區：Y=±20（老搖桿靜止時的容錯範圍）, X=±20
  if (tankMode) {
    // 戰車模式：LW=左輪, RW=右輪
    int lyRaw = ps2x->Analog(PSS_LY);
    int ly = (abs(lyRaw - 128) <= 20) ? 128 : lyRaw;
    // 戰車模式：左搖桿Y軸控制LW，右搖桿Y軸控制RW
    if (ly == 128) { LW->run(BRAKE); }
    else if (ly < 128) { LW->run(FORWARD); LW->setSpeed(map(ly, 128, 0, 0, 255)); }
    else { LW->run(BACKWARD); LW->setSpeed(map(ly, 128, 255, 0, 255)); }
    int ryRaw = ps2x->Analog(PSS_RY);
    int ry = (abs(ryRaw - 128) <= 20) ? 128 : ryRaw;
    if (ry == 128) { RW->run(BRAKE); }
    else if (ry < 128) { RW->run(FORWARD); RW->setSpeed(map(ry, 128, 0, 0, 255)); }
    else { RW->run(BACKWARD); RW->setSpeed(map(ry, 128, 255, 0, 255)); }
  } else {
    // 遙控車模式：LW=左輪, RW=右輪
    {
    int lyRaw2 = ps2x->Analog(PSS_LY);
    int ly = (abs(lyRaw2 - 128) <= 20) ? 128 : lyRaw2;
    int rxRaw2 = ps2x->Analog(PSS_RX);
    int rx = (abs(rxRaw2 - 127) <= 20) ? 127 : rxRaw2;
    int LFS = map(ly, 128, 0, 0, 150) * map(rx, 127, 0, 120, 0) / 100;
    int LBS = map(ly, 128, 255, 0, 150) * map(rx, 127, 0, 120, 0) / 100;
    int RFS = map(ly, 128, 0, 0, 150) * map(rx, 127, 255, 120, 0) / 100;
    int RBS = map(ly, 128, 255, 0, 150) * map(rx, 127, 255, 120, 0) / 100;
    if (ly == 128 && rx == 127) {
      LW->run(BRAKE);
      RW->run(BRAKE);
    } else if (ly == 128 && rx < 127) {
      LW->run(BACKWARD);
      LW->setSpeed(map(rx, 128, 0, 80, 255));
      RW->run(FORWARD);
      RW->setSpeed(map(rx, 128, 0, 80, 255));
    } else if (ly == 128 && rx > 127) {
      LW->run(FORWARD);
      LW->setSpeed(map(rx, 128, 255, 80, 255));
      RW->run(BACKWARD);
      RW->setSpeed(map(rx, 128, 255, 80, 255));
    } else if (ly < 128 && rx < 127) {
      LW->run(FORWARD);
      LW->setSpeed(LFS);
      RW->run(FORWARD);
      RW->setSpeed(map(ly, 128, 0, 40, 255));
    } else if (ly < 128 && rx > 127) {
      LW->run(FORWARD);
      LW->setSpeed(map(ly, 128, 0, 40, 255));
      RW->run(FORWARD);
      RW->setSpeed(RFS);
    } else if (ly > 128 && rx < 127) {
      LW->run(BACKWARD);
      LW->setSpeed(LBS);
      RW->run(BACKWARD);
      RW->setSpeed(map(ly, 128, 255, 40, 255));
    } else if (ly > 128 && rx > 127) {
      LW->run(BACKWARD);
      LW->setSpeed(map(ly, 128, 255, 40, 255));
      RW->run(BACKWARD);
      RW->setSpeed(RBS);
    } else if (ly < 128) {
      LW->run(FORWARD);
      LW->setSpeed(map(ly, 128, 0, 40, 255));
      RW->run(FORWARD);
      RW->setSpeed(map(ly, 128, 0, 40, 255));
    } else if (ly > 128) {
      LW->run(BACKWARD);
      LW->setSpeed(map(ly, 128, 255, 40, 255));
      RW->run(BACKWARD);
      RW->setSpeed(map(ly, 128, 255, 40, 255));
    }
    }
  }

  // ---- Servo1 (方形/圓形鍵) ----
  if (ps2x->Button(PSB_CIRCLE)) {
    Servo1->writeServo(35);
  } else if (ps2x->Button(PSB_SQUARE)) {
    Servo1->writeServo(115);
  } else {
    Servo1->writeServo(Servo1_IDLE);
  }

  // ---- Servo3 (三角/叉叉鍵) ----
  if (ps2x->Button(PSB_TRIANGLE)) {
    Servo3->writeServo(135);
  } else if (ps2x->Button(PSB_CROSS)) {
    Servo3->writeServo(40);
  } else {
    Servo3->writeServo(Servo3_IDLE);
  }

  // ---- Servo4 (左搖桿X軸) ----
  Servo4->writeServo(map(ps2x->Analog(PSS_LX), 0, 255, 60, 90));

  delay(50);
}

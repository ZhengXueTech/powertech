/*
 * PowerTech 清道達人 T-Display 藍牙遙控器
 * 學思創客 ZhengXueTech ｜ https://zhengxuetech.github.io/powertech/ ｜ CC BY-NC-SA 4.0
 *
 * 硬體：LILYGO T-Display（ESP32，V1.1）
 * 小車：清道達人 CC2541 類 BLE 模組（服務 FFE0／特徵 FFE1）
 * 協定：連線期間每 60ms 送 1 個位元組，每個位元一顆按鈕，00 = 全停
 *   01/02 = M1 右前輪  04/08 = M2 滾刷  10/20 = M3 後門  40/80 = M4 左前輪
 *
 * ───────── 操作 ─────────
 * 【選車畫面】開機自動掃描，依訊號強度列出附近藍牙裝置
 *   左鍵短按：往下選　左鍵長按 1 秒：重新掃描　右鍵短按：連線（上次的車會自動選好）
 * 【駕駛畫面】按住才動、放開就停
 *   板上左鍵 = 左輪前進　板上右鍵 = 右輪前進　兩鍵同按 = 直走
 *   外接按鍵（一腳接 GPIO、對角另一腳接 GND）：
 *     G25 左輪前進  G26 左輪後退  G27 右輪前進  G33 右輪後退
 *     G21 滾刷收球  G22 滾刷吐球  G17 後門 +    G13 後門 −
 *   換車：按側邊 RST 重新開機
 *
 * ───────── Arduino IDE 設定 ─────────
 *   開發板：ESP32 Dev Module（esp32 核心 2.0.17）
 *   Partition Scheme：Huge APP (3MB No OTA/1MB SPIFFS)
 *   TFT_eSPI：User_Setup_Select.h 改用 Setup25_TTGO_T_Display.h
 *
 * ※ 小車一次只能被一個裝置連線，原廠 App 要先斷線
 */

#include <BLEDevice.h>
#include <Preferences.h>
#include <TFT_eSPI.h>
#include <vector>
#include <algorithm>

// ================= 可調整設定 =================
#define INPUT_MODE   1                 // 0 = 鍵盤測試  1 = 按鍵（按住才動）  2 = 搖桿模組
#define USE_JOYSTICK (INPUT_MODE == 2)
const float BTN_SPEED = 0.5;           // 按鍵模式的速度（0~1），熟練後可調到 1.0
const int PIN_LF = 25, PIN_LB = 26, PIN_RF = 27, PIN_RB = 33;   // 外接按鍵：左右輪
const int PIN_BRUSH_IN = 21, PIN_BRUSH_OUT = 22, PIN_DOOR_A = 17, PIN_DOOR_B = 13;   // 外接按鍵：滾刷、後門
#define TANK_MODE    1                 // 1 = 戰車模式（左右輪各自控制）  0 = 單搖桿方向模式
const char *NAME_PREFIX = "";          // 留空 = 列出周圍所有有名稱的藍牙裝置；填 "PT-" 則只列 PT- 開頭的
const int   SEND_MS     = 60;          // 送出間隔（ms），跟原廠 App 一樣約 60ms
const int   KEEP_MS     = 0;           // 0 = 持續送（原廠 App 也是持續送）

// 搖桿接線（USE_JOYSTICK 1 才用到）：兩支搖桿 VCC→3V3  GND→GND
//   戰車模式：左搖桿 VRy→G37、右搖桿 VRy→G38、任一搖桿 SW→G32
//   一般模式：VRx→G36、VRy→G37、SW→G32
const int PIN_X = 36, PIN_Y = 37, PIN_Y2 = 38, PIN_SW = 32;
const float DEADZONE = 0.08;
const bool  INVERT_X = false, INVERT_Y = true;
// ==============================================

const int BTN_L = 0, BTN_R = 35;       // T-Display 板上左右鍵

static BLEUUID SVC_UUID((uint16_t)0xFFE0);
static BLEUUID CHR_UUID((uint16_t)0xFFE1);

TFT_eSPI tft;
Preferences prefs;
BLEClient *client = nullptr;
BLERemoteCharacteristic *chr = nullptr;
volatile bool linked = false;

struct Car { String name; String mac; esp_ble_addr_type_t type; int rssi; };
std::vector<Car> cars;
int sel = 0;
Car cur;

enum State { ST_LIST, ST_DRIVE };
State state = ST_LIST;

float speedScale = (INPUT_MODE == 2) ? 1.0 : (INPUT_MODE == 1) ? BTN_SPEED : 0.3;
int cmdX = 0, cmdY = 0;                // 鍵盤模式：一般模式 X/Y，戰車模式 左輪/右輪
int cX = 2048, cY = 2048, cY2 = 2048;  // 搖桿中心
float showX = 0, showY = 0;
unsigned long lastSend = 0, lastDraw = 0, lastRetry = 0;

class ClientCB : public BLEClientCallbacks {
  void onConnect(BLEClient *c) {}
  void onDisconnect(BLEClient *c) { linked = false; }
};

// ---------------- 按鍵（短按 / 長按） ----------------
struct Btn { int pin; bool down; unsigned long t0; bool longFired; };
Btn bL = {BTN_L, false, 0, false};
Btn bR = {BTN_R, false, 0, false};

// 回傳 0 無、1 短按（放開時觸發）、2 長按（按住超過 longMs 觸發一次）
int pollBtn(Btn &b, unsigned long longMs) {
  bool pressed = digitalRead(b.pin) == LOW;
  if (pressed && !b.down) { b.down = true; b.t0 = millis(); b.longFired = false; }
  else if (pressed && b.down) {
    if (!b.longFired && millis() - b.t0 > longMs) { b.longFired = true; return 2; }
  } else if (!pressed && b.down) {
    b.down = false;
    if (!b.longFired && millis() - b.t0 > 30) return 1;
  }
  return 0;
}

// ---------------- 畫面 ----------------
void drawMsg(const char *l1, const char *l2, uint16_t color) {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(color, TFT_BLACK);
  tft.drawString(l1, 8, 30, 4);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString(l2, 8, 75, 2);
}

void drawList() {
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  char head[40];
  snprintf(head, sizeof(head), "SELECT DEVICE (%d)   signal", (int)cars.size());
  tft.drawString(head, 6, 4, 2);
  if (cars.empty()) {
    tft.setTextColor(TFT_ORANGE, TFT_BLACK);
    tft.drawString("Nothing found", 6, 45, 4);
  } else {
    int top = sel > 4 ? sel - 4 : 0;   // 一頁顯示 5 台
    for (int i = top; i < (int)cars.size() && i < top + 5; i++) {
      int y = 26 + (i - top) * 18;
      bool on = (i == sel);
      if (on) tft.fillRect(0, y - 1, 240, 18, TFT_DARKGREEN);
      tft.setTextColor(TFT_WHITE, on ? TFT_DARKGREEN : TFT_BLACK);
      String line = String(on ? "> " : "  ") + cars[i].name;
      tft.drawString(line, 6, y, 2);
      tft.setTextColor(TFT_LIGHTGREY, on ? TFT_DARKGREEN : TFT_BLACK);
      tft.drawString(String(cars[i].rssi), 200, y, 2);   // 訊號強度
    }
  }
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.drawString("L:next  hold L:rescan  R:connect", 6, 120, 1);
}

void drawDrive(bool force) {
  if (!force && millis() - lastDraw < 150) return;
  lastDraw = millis();
  char line[40];
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  snprintf(line, sizeof(line), "%-20s", cur.name.c_str());
  tft.drawString(line, 6, 4, 2);
  tft.setTextColor(linked ? TFT_GREEN : TFT_ORANGE, TFT_BLACK);
  tft.drawString(linked ? "CONNECTED     " : "RECONNECTING..", 6, 26, 4);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
#if TANK_MODE
  snprintf(line, sizeof(line), "L %+.2f  R %+.2f  ", showX, showY);
#else
  snprintf(line, sizeof(line), "X %+.2f  Y %+.2f  ", showX, showY);
#endif
  tft.drawString(line, 6, 60, 4);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  snprintf(line, sizeof(line), "SPEED %.1f   ", speedScale);
  tft.drawString(line, 6, 94, 2);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.drawString(INPUT_MODE == 1 ? "press RST: change car" : "hold L 2s: change car", 6, 120, 1);
}

// ---------------- BLE ----------------
void doScan() {
  drawMsg("SCANNING...", "Looking for cars (3s)", TFT_ORANGE);
  BLEScan *scan = BLEDevice::getScan();
  scan->setActiveScan(true);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  BLEScanResults *res = scan->start(3, false);
#else
  BLEScanResults r = scan->start(3, false);
  BLEScanResults *res = &r;
#endif
  cars.clear();
  String last = prefs.getString("mac", "");
  Serial.println("--- 掃描結果 ---");
  for (int i = 0; i < res->getCount(); i++) {
    BLEAdvertisedDevice d = res->getDevice(i);
    if (!d.haveName()) continue;
    String nm = d.getName().c_str();
    String mac = d.getAddress().toString().c_str();
    int rssi = d.haveRSSI() ? d.getRSSI() : -100;
    Serial.printf("  %-18s %s  訊號 %d\n", nm.c_str(), mac.c_str(), rssi);
    if (strlen(NAME_PREFIX) > 0 && !nm.startsWith(NAME_PREFIX)) continue;
    bool dup = false;
    for (auto &c : cars) if (c.mac == mac) dup = true;
    if (!dup) cars.push_back({nm, mac, d.getAddressType(), rssi});
  }
  scan->clearResults();
  // 依訊號強度排序：越接近 0 越近，排越前面
  std::sort(cars.begin(), cars.end(), [](const Car &a, const Car &b) { return a.rssi > b.rssi; });
  sel = 0;
  for (int i = 0; i < (int)cars.size(); i++) if (cars[i].mac == last) sel = i;  // 自動選上次用的車
  drawList();
}

bool connectCar(const Car &c) {
  if (!client->connect(BLEAddress(c.mac.c_str()), c.type)) return false;
  BLERemoteService *svc = client->getService(SVC_UUID);
  if (!svc) { client->disconnect(); return false; }
  chr = svc->getCharacteristic(CHR_UUID);
  if (!chr) { client->disconnect(); return false; }
  linked = true;
  prefs.putString("mac", c.mac);       // 記住這台車
  Serial.printf("已連上 %s (%s)\n", c.name.c_str(), c.mac.c_str());
  return true;
}

// ===== 清道達人協定：持續送 1 個位元組，每個位元一顆按鈕，00 = 全停 =====
//   01 ˅ / 02 ˄ : M1 右前輪     04 ‹ / 08 › : M2 滾刷
//   10 − / 20 + : M3 後門       40 A / 80 B : M4 左前輪
// 前進／後退方向若相反，把下面對應的兩個值對調即可
const uint8_t R_FWD = 0x02, R_BACK = 0x01;   // 右輪 M1
const uint8_t L_FWD = 0x80, L_BACK = 0x40;   // 左輪 M4
const uint8_t BRUSH_IN = 0x04, BRUSH_OUT = 0x08;   // 滾刷 M2
const uint8_t DOOR_A = 0x20, DOOR_B = 0x10;        // 後門 M3
uint8_t extraBits = 0;                             // 滾刷／後門等額外按鍵

void sendXY(float x, float y) {
  float L, R;
#if TANK_MODE
  L = x; R = y;                        // x = 左輪、y = 右輪
#else
  L = y + x; R = y - x;                // 方向搖桿換算成左右輪
#endif
  uint8_t b = extraBits;
  if (L > 0.15) b |= L_FWD; else if (L < -0.15) b |= L_BACK;
  if (R > 0.15) b |= R_FWD; else if (R < -0.15) b |= R_BACK;
  if (linked && chr) chr->writeValue(&b, 1, false);
  static uint8_t lastPrinted = 0xFF;
  if (b != lastPrinted) { Serial.printf("送出 %02X\n", b); lastPrinted = b; }
}

// ---------------- 搖桿 ----------------
int readAvg(int pin) {
  long s = 0;
  for (int i = 0; i < 8; i++) s += analogRead(pin);
  return s / 8;
}

float normAxis(int raw, int center, bool invert) {
  float v = (raw >= center) ? (float)(raw - center) / (4095 - center)
                            : (float)(raw - center) / center;
  if (fabs(v) < DEADZONE) v = 0;
  else v = (v > 0 ? v - DEADZONE : v + DEADZONE) / (1 - DEADZONE);
  v = constrain(v, -1.0, 1.0);
  return invert ? -v : v;
}

// ---------------- 主程式 ----------------
void setup() {
  Serial.begin(115200);
  pinMode(BTN_L, INPUT_PULLUP);
  pinMode(BTN_R, INPUT);               // GPIO35 板上已有上拉電阻
#if INPUT_MODE == 1
  pinMode(PIN_LF, INPUT_PULLUP);
  pinMode(PIN_LB, INPUT_PULLUP);
  pinMode(PIN_RF, INPUT_PULLUP);
  pinMode(PIN_RB, INPUT_PULLUP);
  pinMode(PIN_BRUSH_IN, INPUT_PULLUP);
  pinMode(PIN_BRUSH_OUT, INPUT_PULLUP);
  pinMode(PIN_DOOR_A, INPUT_PULLUP);
  pinMode(PIN_DOOR_B, INPUT_PULLUP);
#endif
  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);
  prefs.begin("blejoy", false);

#if USE_JOYSTICK
  pinMode(PIN_SW, INPUT_PULLUP);
  analogSetAttenuation(ADC_11db);
  delay(300);                          // 開機時不要碰搖桿
  cX = readAvg(PIN_X);
  cY = readAvg(PIN_Y);
  cY2 = readAvg(PIN_Y2);
#endif

  BLEDevice::init("DIY_Controller");
  client = BLEDevice::createClient();
  client->setClientCallbacks(new ClientCB());
  doScan();
}

void loopList() {
  int l = pollBtn(bL, 1000);
  int r = pollBtn(bR, 1000);
  if (l == 2 || (l == 1 && cars.empty())) { doScan(); return; }
  if (l == 1 && !cars.empty()) { sel = (sel + 1) % cars.size(); drawList(); }
  if (r == 1 && !cars.empty()) {
    cur = cars[sel];
    drawMsg("CONNECTING..", cur.name.c_str(), TFT_ORANGE);
    if (connectCar(cur)) {
      state = ST_DRIVE;
      cmdX = cmdY = 0;
      tft.fillScreen(TFT_BLACK);
      drawDrive(true);
    } else {
      drawMsg("FAILED", "Phone still connected? Car off?", TFT_RED);
      delay(1500);
      drawList();
    }
  }
}

void loopDrive() {
  // 長按左鍵 2 秒：停車、斷線、回選車畫面（按鍵模式左鍵用來開車，改用 RST 換車）
  if (INPUT_MODE != 1 && pollBtn(bL, 2000) == 2) {
    sendXY(0, 0);
    delay(100);
    if (linked) client->disconnect();
    linked = false;
    state = ST_LIST;
    doScan();
    return;
  }
  pollBtn(bR, 1000);

  // 意外斷線：每 3 秒自動重連同一台
  if (!linked) {
    drawDrive(false);
    if (millis() - lastRetry > 3000) { lastRetry = millis(); connectCar(cur); }
    return;
  }

#if INPUT_MODE == 1
  // 按鍵模式：按住才動，放開就停（序列埠仍可用 1/2/3 調速）
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '1') speedScale = 0.3;
    if (c == '2') speedScale = 0.6;
    if (c == '3') speedScale = 1.0;
  }
  bool lf = digitalRead(BTN_L) == LOW || digitalRead(PIN_LF) == LOW;
  bool lb = digitalRead(PIN_LB) == LOW;
  bool rf = digitalRead(BTN_R) == LOW || digitalRead(PIN_RF) == LOW;
  bool rb = digitalRead(PIN_RB) == LOW;
  // 滾刷、後門（同一顆馬達兩個方向同時按就都不送）
  bool bi = digitalRead(PIN_BRUSH_IN) == LOW, bo = digitalRead(PIN_BRUSH_OUT) == LOW;
  bool da = digitalRead(PIN_DOOR_A) == LOW,   db = digitalRead(PIN_DOOR_B) == LOW;
  extraBits = 0;
  if (bi != bo) extraBits |= bi ? BRUSH_IN : BRUSH_OUT;
  if (da != db) extraBits |= da ? DOOR_A : DOOR_B;
  int L = (lf && !lb) ? 1 : (lb && !lf) ? -1 : 0;
  int R = (rf && !rb) ? 1 : (rb && !rf) ? -1 : 0;
#if TANK_MODE
  cmdX = L; cmdY = R;
#else
  cmdX = constrain(L - R, -1, 1); cmdY = (L + R) / 2;   // 一般模式換算成方向
#endif
#elif USE_JOYSTICK
  static bool lastSw = HIGH;
  bool sw = digitalRead(PIN_SW);
  if (lastSw == HIGH && sw == LOW) speedScale = (speedScale > 0.9) ? 0.5 : 1.0;
  lastSw = sw;
#else
  while (Serial.available()) {
    char c = tolower(Serial.read());
    switch (c) {
#if TANK_MODE                          // cmdX = 左輪、cmdY = 右輪
      case 'q': cmdX = 1;  break;
      case 'a': cmdX = -1; break;
      case 'z': cmdX = 0;  break;
      case 'e': cmdY = 1;  break;
      case 'd': cmdY = -1; break;
      case 'c': cmdY = 0;  break;
      case 'w': cmdX = 1;  cmdY = 1;  break;
      case 's': cmdX = -1; cmdY = -1; break;
#else
      case 'w': cmdX = 0;  cmdY = 1;  break;
      case 's': cmdX = 0;  cmdY = -1; break;
      case 'a': cmdX = -1; cmdY = 0;  break;
      case 'd': cmdX = 1;  cmdY = 0;  break;
#endif
      case 'x': cmdX = 0;  cmdY = 0;  break;
      case '1': speedScale = 0.3; break;
      case '2': speedScale = 0.6; break;
      case '3': speedScale = 1.0; break;
      default: continue;
    }
    Serial.printf(">> 指令 %c\n", c);
  }
  // 板上任一鍵按下 = 緊急停止
  if (digitalRead(BTN_L) == LOW || digitalRead(BTN_R) == LOW) { cmdX = 0; cmdY = 0; }
#endif

  drawDrive(false);
  if (millis() - lastSend < SEND_MS) return;
  lastSend = millis();

#if USE_JOYSTICK && TANK_MODE
  showX = normAxis(readAvg(PIN_Y),  cY,  INVERT_Y) * speedScale;   // 左輪
  showY = normAxis(readAvg(PIN_Y2), cY2, INVERT_Y) * speedScale;   // 右輪
#elif USE_JOYSTICK
  showX = normAxis(readAvg(PIN_X), cX, INVERT_X) * speedScale;
  showY = normAxis(readAvg(PIN_Y), cY, INVERT_Y) * speedScale;
#else
  showX = cmdX * speedScale;
  showY = cmdY * speedScale;
#endif
  // 有變化才送；沒變化每 KEEP_MS 補送一次，降低藍牙負擔
  static float sentX = 99, sentY = 99;
  static unsigned long lastKeep = 0;
  bool changed = fabs(showX - sentX) >= 0.02 || fabs(showY - sentY) >= 0.02;
  if (!changed && millis() - lastKeep < KEEP_MS) return;
  sendXY(showX, showY);
  sentX = showX; sentY = showY; lastKeep = millis();
}

void loop() {
  if (state == ST_LIST) loopList();
  else loopDrive();
}

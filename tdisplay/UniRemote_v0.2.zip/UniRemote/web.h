// 手機／平板控制頁（遙控器 Wi-Fi 熱點裡的 http://192.168.4.1/）
// 不需要網路、不載入外部檔案；手機與 iPad 共用，橫放時左右手各控一輪。
#pragma once
#include <pgmspace.h>

const char PAGE_HTML[] PROGMEM = R"HTML(<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<title>清道達人遙控</title>
<style>
:root{--bg:#121417;--panel:#1c2026;--line:#2d333c;--fg:#eceff3;--dim:#8b94a1;--acc:#f2a33a;--ok:#3fcf7f;--bad:#ff6b5b}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
[hidden]{display:none!important}
html,body{margin:0;height:100%;background:var(--bg);color:var(--fg);font-family:-apple-system,"PingFang TC","Noto Sans TC","Microsoft JhengHei",sans-serif;
 -webkit-user-select:none;user-select:none;-webkit-touch-callout:none;overscroll-behavior:none;touch-action:none}
body{display:flex;flex-direction:column;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)}
header{display:flex;align-items:center;gap:10px;padding:8px 14px;border-bottom:1px solid var(--line);font-size:15px}
.dot{width:10px;height:10px;border-radius:50%;background:var(--bad);flex:none}
.dot.ok{background:var(--ok)}
#car{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#info{margin-left:auto;color:var(--dim);font-variant-numeric:tabular-nums;white-space:nowrap}
header button{background:var(--panel);color:var(--fg);border:1px solid var(--line);border-radius:8px;padding:6px 10px;font-size:14px}
/* 配對畫面 */
#pair{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:20px;text-align:center;touch-action:auto}
#pair h1{margin:0;font-size:24px}
#pair p{margin:0;color:var(--dim);line-height:1.6}
#code{font-size:40px;letter-spacing:12px;text-align:center;width:6.2em;padding:10px;border-radius:14px;border:2px solid var(--line);background:var(--panel);color:var(--fg);font-variant-numeric:tabular-nums;-webkit-user-select:text;user-select:text}
#go{font-size:20px;font-weight:700;padding:12px 40px;border:0;border-radius:14px;background:var(--acc);color:#2a1600}
#msg{color:var(--bad);min-height:1.4em}
/* 控制畫面 */
#ctl{flex:1;display:flex;flex-direction:column}
#pad{flex:1;display:grid;gap:12px;padding:12px;grid-template-columns:1fr minmax(150px,.9fr) 1fr;grid-template-areas:"lu mid ru" "ld mid rd"}
.k{border:2px solid var(--line);background:var(--panel);color:var(--fg);border-radius:20px;font-size:clamp(22px,5vmin,44px);font-weight:700;
 display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;touch-action:none}
.k small{font-size:.42em;color:var(--dim);font-weight:500}
.k.on{background:var(--acc);border-color:var(--acc);color:#2a1600}.k.on small{color:#2a1600}
#mid{grid-area:mid;display:grid;gap:10px;grid-template-rows:1fr 1fr .8fr 1fr 1fr}
#mid .k{font-size:clamp(16px,3.4vmin,28px);border-radius:14px}
#latch.on{background:var(--ok);border-color:var(--ok)}
#tx{text-align:center;color:var(--dim);font:14px ui-monospace,Menlo,monospace;padding:0 0 6px}
#banner{display:none;text-align:center;padding:6px;background:#3a1d1a;color:var(--bad);font-size:14px}
@media (orientation:portrait){
 #pad{grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr 1.25fr;grid-template-areas:"lu ru" "ld rd" "mid mid"}
 #mid{grid-template-columns:1fr 1fr 1fr;grid-template-rows:1fr 1fr}
}
</style></head><body>
<header><span class="dot" id="dot"></span><span id="car">連線中…</span><span id="info"></span><button id="fs">全螢幕</button></header>
<div id="banner"></div>

<section id="pair">
 <h1>清道達人遙控</h1>
 <p>輸入遙控器螢幕上的 4 位數配對碼</p>
 <input id="code" inputmode="numeric" pattern="[0-9]*" maxlength="4" autocomplete="off">
 <button id="go">開始控制</button>
 <div id="msg"></div>
 <p id="hint">同一時間只有一支手機能控制。<br>畫面上的按鍵：按住才動，放開就停。</p>
</section>

<section id="ctl" hidden>
 <div id="pad">
  <button class="k" style="grid-area:lu" data-b="1">▲<small>左輪</small></button>
  <button class="k" style="grid-area:ld" data-b="2">▼<small>左輪</small></button>
  <div id="mid">
   <button class="k" data-b="16">收球</button>
   <button class="k" data-b="32">吐球</button>
   <button class="k" id="latch">滾刷常開</button>
   <button class="k" data-b="64">後門 ＋</button>
   <button class="k" data-b="128">後門 −</button>
  </div>
  <button class="k" style="grid-area:ru" data-b="4">▲<small>右輪</small></button>
  <button class="k" style="grid-area:rd" data-b="8">▼<small>右輪</small></button>
 </div>
 <div id="tx">TX 00</div>
</section>

<script>
const $=s=>document.querySelector(s);
let tok=null, held=0, latch=false, running=false, fails=0;
try{tok=sessionStorage.getItem('pt_tok');}catch(e){}

function show(ctl){ $('#pair').hidden=ctl; $('#ctl').hidden=!ctl; }
function banner(t){ const b=$('#banner'); b.textContent=t||''; b.style.display=t?'block':'none'; }
function setStatus(j){
  $('#dot').classList.toggle('ok',!!j.l);
  $('#car').textContent=j.l?j.car:'遙控器未連上小車';
  if(j.tx!==undefined) $('#tx').textContent='TX '+j.tx;
  banner(j.m?'遙控器正在選單中，小車暫停':(j.src===0?'遙控器設定為「只用實體鍵」':''));
}

// ---- 配對 ----
async function pair(){
  const c=$('#code').value.trim();
  if(c.length!==4){ $('#msg').textContent='請輸入 4 位數'; return; }
  $('#msg').textContent='';
  try{
    const j=await (await fetch('/pair?code='+c,{cache:'no-store'})).json();
    if(!j.ok){ $('#msg').textContent=j.msg||'配對失敗'; return; }
    tok=j.t; try{sessionStorage.setItem('pt_tok',tok);}catch(e){}
    $('#code').blur(); show(true); start();
  }catch(e){ $('#msg').textContent='連不到遙控器，請確認已連上遙控器的 Wi-Fi'; }
}
$('#go').onclick=pair;
$('#code').addEventListener('keydown',e=>{ if(e.key==='Enter') pair(); });

function kicked(why){
  running=false; tok=null; try{sessionStorage.removeItem('pt_tok');}catch(e){}
  show(false); $('#msg').textContent=why; $('#code').value='';
  document.querySelectorAll('.k.on').forEach(k=>k.classList.remove('on')); held=0;
}

// ---- 按鍵（多指同時按） ----
document.querySelectorAll('.k[data-b]').forEach(k=>{
  const bit=+k.dataset.b;
  const down=e=>{ e.preventDefault(); k.setPointerCapture?.(e.pointerId); held|=bit; k.classList.add('on'); };
  const up=()=>{ held&=~bit; k.classList.remove('on'); };
  k.addEventListener('pointerdown',down); k.addEventListener('pointerup',up);
  k.addEventListener('pointercancel',up); k.addEventListener('lostpointercapture',up);
  k.addEventListener('contextmenu',e=>e.preventDefault());
});
$('#latch').addEventListener('pointerdown',e=>{ e.preventDefault(); latch=!latch; $('#latch').classList.toggle('on',latch); });
// 鍵盤（平板外接鍵盤）：W/S 左輪、I/K 右輪、A/D 滾刷、J/L 後門
const KB={w:1,s:2,i:4,k:8,a:16,d:32,l:64,j:128};
addEventListener('keydown',e=>{ const b=KB[e.key.toLowerCase()]; if(b&&tok){ held|=b; e.preventDefault(); }});
addEventListener('keyup',e=>{ const b=KB[e.key.toLowerCase()]; if(b) held&=~b; });

function bits(){
  let b=held;
  if(latch && !(b&48)) b|=16;            // 滾刷常開：沒按收／吐時持續收球
  return b;
}

// ---- 每 60ms 送一次；回應帶回小車狀態 ----
async function tick(){
  if(!running) return;
  const t0=performance.now();
  const ac=new AbortController(); const to=setTimeout(()=>ac.abort(),900);
  try{
    const r=await fetch('/c?t='+tok+'&b='+bits().toString(16),{cache:'no-store',signal:ac.signal});
    if(r.status===403){ kicked('控制權已收回（配對碼已更換或遙控器重新開機），請重新輸入配對碼'); return; }
    const j=await r.json(); fails=0; setStatus(j);
    $('#info').textContent=Math.round(performance.now()-t0)+' ms';
  }catch(e){
    fails++; $('#dot').classList.remove('ok');
    $('#info').textContent='訊號不穩'; if(fails>3) banner('連不到遙控器：請確認 Wi-Fi 仍連著遙控器（小車會自動停下）');
  }finally{ clearTimeout(to); }
  setTimeout(tick, Math.max(0, 60-(performance.now()-t0)));
}
function start(){ if(!running){ running=true; tick(); } }

// 切到別的 App 或關螢幕：停止送出，遙控器 0.4 秒後自動停車
document.addEventListener('visibilitychange',()=>{
  if(document.hidden){ running=false; held=0; document.querySelectorAll('.k.on').forEach(k=>k.classList.remove('on')); }
  else if(tok) start();
});

$('#fs').onclick=()=>{ const d=document.documentElement; (d.requestFullscreen||d.webkitRequestFullscreen)?.call(d); try{screen.orientation.lock('landscape');}catch(e){} };

// 開啟頁面：有舊的控制權就直接用，沒有就顯示配對畫面
async function boot(){
  try{ const j=await (await fetch('/s',{cache:'no-store'})).json(); setStatus(j);
       if(j.busy && !tok) $('#msg').textContent='目前有其他手機在控制'; }catch(e){}
  if(tok){ show(true); start(); } else show(false);
}
boot();
</script></body></html>)HTML";

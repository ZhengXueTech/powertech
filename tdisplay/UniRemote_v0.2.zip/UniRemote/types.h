// 型別定義放在獨立的標頭檔：
// Arduino IDE 會自動在 .ino 最前面產生函式宣告，型別若寫在 .ino 裡會「找不到型別」
#pragma once
#include <Arduino.h>

enum Key { K_LU, K_LD, K_LL, K_LR, K_RU, K_RD, K_RL, K_RR, K_MENU, K_LATCH, K_A, K_B, NKEY };
enum Fn { F_L, F_R, F_BRUSH, F_DOOR };
enum Screen { SC_BOOT, SC_DRIVE, SC_MENU, SC_SCAN, SC_TEST, SC_MTEST, SC_QR, SC_PQR };
struct Car { String name, mac; uint8_t type; int rssi; };
enum MenuId { M_ROOT, M_CONN, M_MOTOR, M_DISP, M_TARGET, M_ABOUT, M_PHONE };
enum Kind : uint8_t { SUB, ACT, OFF, INFO };
enum Code : uint8_t { C_NONE, C_SCAN, C_RECONN, C_FORGET, C_CUR, C_MAP0, C_MAP1, C_MAP2, C_MAP3,
                      C_REV0, C_REV1, C_REV2, C_REV3, C_MTEST, C_RESET, C_BRIGHT, C_LOCK,
                      C_KEYTEST, C_PT, C_VER, C_BOARD, C_QR,
                      C_WIFI, C_CODE, C_SRC, C_PQR, C_KICK };
enum Src : uint8_t { SRC_PHYS, SRC_PHONE, SRC_MIX };
struct Item { const char *label; Kind kind; uint8_t arg; };
struct MenuDef { const char *title; const Item *items; uint8_t n; };
struct Level { uint8_t id, idx, top; };

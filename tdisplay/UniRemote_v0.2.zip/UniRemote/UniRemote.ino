/*
 * 萬用遙控器 韌體 v0.2（UniRemote）
 * ==========================================================
 * 學思創客．PowerTech 工具箱  https://zhengxuetech.github.io/powertech/
 *
 * 這一版做什麼：
 *   - 藍牙（BLE）控制清道達人：戰車式按住才動、滾刷常開、每 60ms 送 1 個位元組
 *   - 選單：選車、馬達對應／反轉、單顆馬達測試、按鍵測試、亮度、比賽鎖定
 *   - 設定存在板子裡（拔電也不會忘）
 *   - 手機 Wi-Fi 中繼（v0.2）：遙控器開 Wi-Fi 熱點，iPhone／iPad／Android 用瀏覽器
 *     打開 http://192.168.4.1 輸入配對碼即可控制；不需網路、不用裝 App
 *     ．配對碼每次開機更換；一次只有一支手機能控制；選單可「換碼踢掉手機」
 *     ．手機訊號中斷 0.4 秒自動停車；實體鍵在「混合」模式下永遠有效
 *
 * 板子：程式會自動判斷 T-Display V1.1（ESP32）或 T-Display S3。
 * Arduino IDE 設定（esp32 開發板套件用 2.0.x，例如 2.0.17）：
 *   V1.1：開發板 ESP32 Dev Module，TFT_eSPI 設定檔 Setup25_TTGO_T_Display
 *   S3  ：開發板 ESP32S3 Dev Module，USB CDC On Boot Enabled，PSRAM OPI，
 *         Flash 16MB，TFT_eSPI 設定檔 Setup206_LilyGo_T_Display_S3
 *   兩塊都要：Partition Scheme = Huge APP (3MB No OTA/1MB SPIFFS)
 *
 * 按鍵（按下 = 接到 GND，不需要電阻）：見下方「腳位」。
 * 沒接外部按鍵也能操作選單：
 *   板子左鍵（BOOT）＝下一項；右鍵（KEY）短按＝確定、長按＝返回；
 *   駕駛畫面長按右鍵 1 秒＝進選單；比賽鎖定時兩顆板載鍵一起長按 3 秒解鎖。
 */
#include <BLEDevice.h>
#include <Preferences.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <WebServer.h>
#include <vector>
#include <algorithm>
#include "types.h"      // 列舉與結構
#include "assets.h"     // 字型（Noto Sans CJK TC 子集，SIL OFL）
#include "web.h"        // 手機控制頁
#include "qrcodegen.h"  // QR Code 產生（Project Nayuki，MIT）

#define FW_VERSION "v0.2"

// ======================== 手機 Wi-Fi 中繼 ========================
const char *AP_PASS = "ccjhsmaker";     // Wi-Fi 密碼（至少 8 碼，全小寫）；改成 "" 就不設密碼
const uint32_t FAILSAFE_MS = 400;       // 手機超過這麼久沒送指令 → 視為放開（停車）
const char *SITE_URL = "https://zhengxuetech.github.io/powertech/";

// ======================== 腳位 ========================
//              左▲ 左▼ 收  吐  右▲ 右▼ 門− 門＋ 選單 常開  板左 板右
#if CONFIG_IDF_TARGET_ESP32S3
  #define BOARD_NAME "T-Display S3"
  #define PIN_POWER_ON 15
  #define PIN_BL 38
  const int8_t PINS[] = { 1,  2, 13, 16,  3, 10, 18, 17, 11, 12,   0, 14 };
#else
  #define BOARD_NAME "T-Display V1.1"
  #define PIN_BL 4
  const int8_t PINS[] = { 25, 26, 21, 22, 27, 33, 13, 17, 32, 15,   0, 35 };
#endif
const char *KEYNAME[NKEY] = { "左▲", "左▼", "收", "吐", "右▲", "右▼", "門−", "門＋", "選單", "常開", "板左", "板右" };

// ======================== 協定 ========================
// 清道達人：每個位元一顆按鈕，00 = 全停
//   M1：02 正 / 01 反    M2：04 正 / 08 反    M3：20 正 / 10 反    M4：80 正 / 40 反
const uint8_t PORT_F[4] = { 0x02, 0x04, 0x20, 0x80 };
const uint8_t PORT_B[4] = { 0x01, 0x08, 0x10, 0x40 };
const char *FNNAME[4] = { "左輪", "右輪", "滾刷", "後門" };
static BLEUUID SVC_UUID((uint16_t)0xFFE0);
static BLEUUID CHR_UUID((uint16_t)0xFFE1);
const uint32_t TX_MS = 60;

// ======================== 顏色 ========================
const uint16_t C_BG = TFT_BLACK, C_FG = 0xEF9E, C_DIM = 0x7C10, C_ACC = 0xFD86,
               C_OK = 0x46B0, C_BAD = 0xFAEB, C_BAR = 0x10C4, C_SEL = 0x2902, C_BOX = 0x10A2;

// ======================== 設定（存在 Flash） ========================
Preferences prefs;
struct Settings {
  uint8_t map[4] = { 3, 0, 1, 2 };   // 左輪 M4、右輪 M1、滾刷 M2、後門 M3
  uint8_t rev = 0;                   // 位元 0~3：各功能反轉
  uint8_t bright = 100;
  bool lock = false;
  String mac, name;
  uint8_t atype = 0;
  bool wifi = true;                  // 開機就開 Wi-Fi 熱點
  uint8_t src = SRC_MIX;             // 操作來源：實體鍵／手機／混合
} S;
void saveSettings() {
  prefs.putBytes("map", S.map, 4);
  prefs.putUChar("rev", S.rev);
  prefs.putUChar("bri", S.bright);
  prefs.putBool("lock", S.lock);
  prefs.putString("mac", S.mac);
  prefs.putString("name", S.name);
  prefs.putUChar("atype", S.atype);
  prefs.putBool("wifi", S.wifi);
  prefs.putUChar("src", S.src);
}
void loadSettings() {
  if (prefs.getBytesLength("map") == 4) prefs.getBytes("map", S.map, 4);
  S.rev = prefs.getUChar("rev", 0);
  S.bright = prefs.getUChar("bri", 100);
  S.lock = prefs.getBool("lock", false);
  S.mac = prefs.getString("mac", "");
  S.name = prefs.getString("name", "");
  S.atype = prefs.getUChar("atype", 0);
  S.wifi = prefs.getBool("wifi", true);
  S.src = prefs.getUChar("src", SRC_MIX);
}

// ======================== 狀態 ========================
TFT_eSPI tft;
int W, H, HB;                        // 螢幕寬、高、標題列高度
Screen screen = SC_BOOT;
bool needFull = true;
bool latch = false;                  // 滾刷常開
uint8_t txNow = 0;
String toastMsg; uint32_t toastUntil = 0;

// ======================== 按鍵 ========================
struct Btn { bool down = false, raw = false, used = false; uint32_t chg = 0, t0 = 0; } btn[NKEY];
inline bool isDown(int k) { return btn[k].down; }
inline uint32_t heldMs(int k) { return btn[k].down ? millis() - btn[k].t0 : 0; }
void onPress(int k);
void onRelease(int k, uint32_t dur, bool used);
void drawToast();

void pollKeys() {
  uint32_t now = millis();
  for (int k = 0; k < NKEY; k++) {
    if (PINS[k] < 0) continue;
    bool r = digitalRead(PINS[k]) == LOW;
    if (r != btn[k].raw) { btn[k].raw = r; btn[k].chg = now; }
    if (btn[k].raw != btn[k].down && now - btn[k].chg > 20) {    // 防彈跳 20ms
      btn[k].down = btn[k].raw;
      if (btn[k].down) { btn[k].t0 = now; btn[k].used = false; onPress(k); }
      else onRelease(k, now - btn[k].t0, btn[k].used);
    }
  }
}

// ======================== 繪圖工具 ========================
const uint8_t *curFont = nullptr;
void useFont(const uint8_t *f) {
  if (f == curFont) return;
  if (curFont) tft.unloadFont();
  tft.loadFont(f);
  curFont = f;
}
int textW(const uint8_t *f, const char *s) { useFont(f); return tft.textWidth(s); }
// align：0 左、1 中、2 右；y 為文字上緣
void text(const uint8_t *f, const char *s, int x, int y, uint16_t fg, uint16_t bg = C_BG, int align = 0) {
  useFont(f);
  int w = tft.textWidth(s);
  if (align == 1) x -= w / 2; else if (align == 2) x -= w;
  tft.setTextColor(fg, bg);
  tft.setCursor(x, y);
  tft.print(s);
}
void header(const char *title, const char *right = "", uint16_t rc = C_DIM) {
  tft.fillRect(0, 0, W, HB, C_BAR);
  text(font14, title, 5, (HB - 15) / 2, C_ACC, C_BAR);
  if (right[0]) {
    bool ascii = true; for (const char *p = right; *p; p++) if ((uint8_t)*p > 127) ascii = false;
    text(ascii ? font12 : font14, right, W - 5, (HB - (ascii ? 12 : 15)) / 2, rc, C_BAR, 2);
  }
}
void setBright(uint8_t pct) {
  uint32_t duty = 255UL * pct / 100;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(PIN_BL, duty);
#else
  ledcWrite(0, duty);
#endif
}
void toast(const String &m) { toastMsg = m; toastUntil = millis() + 1300; drawToast(); }
void drawToast() {
  int w = textW(font14, toastMsg.c_str()) + 20, h = 26;
  int x = (W - w) / 2, y = (H - h) / 2;
  tft.fillRoundRect(x, y, w, h, 6, 0x3186);
  text(font14, toastMsg.c_str(), W / 2, y + 5, C_FG, 0x3186, 1);
}

// ======================== 藍牙 ========================
std::vector<Car> cars;
BLEClient *client = nullptr;
BLERemoteCharacteristic *chr = nullptr;
volatile bool linked = false;
bool connecting = false;
int retries = 0; uint32_t nextRetry = 0;

class ClientCB : public BLEClientCallbacks {
  void onConnect(BLEClient *c) {}
  void onDisconnect(BLEClient *c) { linked = false; chr = nullptr; }
};

void busy(const char *l1, const char *l2) {      // 連線／掃描時會卡住幾秒，先畫提示
  tft.fillScreen(C_BG);
  header("清道達人");
  text(font20, l1, W / 2, H / 2 - 22, C_ACC, C_BG, 1);
  text(font14, l2, W / 2, H / 2 + 6, C_DIM, C_BG, 1);
}

void scanCars(uint32_t sec) {
  BLEScan *scan = BLEDevice::getScan();
  scan->setActiveScan(true);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  BLEScanResults *res = scan->start(sec, false);
#else
  BLEScanResults r = scan->start(sec, false);
  BLEScanResults *res = &r;
#endif
  cars.clear();
  for (int i = 0; i < res->getCount(); i++) {
    BLEAdvertisedDevice d = res->getDevice(i);
    if (!d.haveName()) continue;
    String mac = d.getAddress().toString().c_str();
    bool dup = false; for (auto &c : cars) if (c.mac == mac) dup = true;
    if (!dup) cars.push_back({ String(d.getName().c_str()), mac, (uint8_t)d.getAddressType(), d.haveRSSI() ? d.getRSSI() : -100 });
  }
  scan->clearResults();
  std::sort(cars.begin(), cars.end(), [](const Car &a, const Car &b) { return a.rssi > b.rssi; });
  Serial.printf("掃描到 %d 個裝置\n", (int)cars.size());
}

bool connectCar(const Car &c) {
  busy("連線中…", c.name.c_str());
  if (linked) { client->disconnect(); delay(300); }
  if (!client->connect(BLEAddress(c.mac.c_str()), (esp_ble_addr_type_t)c.type)) return false;
  BLERemoteService *svc = client->getService(SVC_UUID);
  if (svc) chr = svc->getCharacteristic(CHR_UUID);
  if (!svc || !chr) { client->disconnect(); return false; }
  linked = true;
  S.mac = c.mac; S.name = c.name; S.atype = c.type; saveSettings();
  Serial.printf("已連線 %s (%s)\n", c.name.c_str(), c.mac.c_str());
  return true;
}

// 用記住的車重新連線：先掃 2 秒確定車在附近，避免連線卡很久
bool reconnectSaved() {
  if (S.mac == "") return false;
  busy("尋找小車…", S.name.c_str());
  scanCars(2);
  for (auto &c : cars) if (c.mac == S.mac) return connectCar(c);
  return false;
}

// ======================== Wi-Fi 熱點＋手機控制 ========================
WebServer server(80);
String apSsid;
char pairCode[5] = "0000";
uint32_t phoneToken = 0, phoneLast = 0;   // 取得控制權的手機（token）與最後一次收到指令的時間
uint8_t phoneBits = 0;                    // 手機按住的按鍵（位元：左▲1 左▼2 右▲4 右▼8 收16 吐32 門＋64 門−128）
bool wifiUp = false;

bool phoneFresh() { return phoneToken && millis() - phoneLast < FAILSAFE_MS; }
bool phoneActive() { return phoneToken && millis() - phoneLast < 3000; }
void newPairCode() { snprintf(pairCode, sizeof pairCode, "%04u", (unsigned)(esp_random() % 9000 + 1000)); }
void kickPhone() { phoneToken = 0; phoneBits = 0; needFull = true; }

String jsonEsc(const String &v) {
  String o; for (unsigned i = 0; i < v.length(); i++) { char c = v[i]; if (c == '"' || c == '\\') o += '\\'; o += c; } return o;
}
String statusJson(bool ok) {
  char b[200];
  snprintf(b, sizeof b, "{\"ok\":%d,\"l\":%d,\"car\":\"%s\",\"m\":%d,\"src\":%d,\"tx\":\"%02X\",\"busy\":%d}",
           ok, linked ? 1 : 0, jsonEsc(S.name).c_str(), screen != SC_DRIVE, S.src, txNow, phoneActive());
  return b;
}
void sendJson(int code, const String &body) {
  server.sendHeader("Cache-Control", "no-store");
  server.send(code, "application/json", body);
}
void hPage() { server.sendHeader("Cache-Control", "no-store"); server.send_P(200, "text/html", PAGE_HTML); }
void hStatus() { sendJson(200, statusJson(1)); }
void hPair() {
  if (S.src == SRC_PHYS) { sendJson(200, "{\"ok\":0,\"msg\":\"遙控器設定為「只用實體鍵」\"}"); return; }
  if (server.arg("code") != pairCode) { sendJson(200, "{\"ok\":0,\"msg\":\"配對碼錯誤，請看遙控器螢幕\"}"); return; }
  if (phoneActive()) { sendJson(200, "{\"ok\":0,\"msg\":\"已有其他手機在控制，請稍候\"}"); return; }
  phoneToken = esp_random() | 1; phoneLast = millis(); phoneBits = 0; needFull = true;
  char b[48]; snprintf(b, sizeof b, "{\"ok\":1,\"t\":\"%08x\"}", phoneToken);
  sendJson(200, b);
  Serial.println("手機取得控制權");
}
void hCtl() {
  uint32_t t = strtoul(server.arg("t").c_str(), nullptr, 16);
  if (!phoneToken || t != phoneToken) { sendJson(403, "{\"ok\":0}"); return; }
  phoneBits = strtoul(server.arg("b").c_str(), nullptr, 16);
  phoneLast = millis();
  sendJson(200, statusJson(1));
}
void hOther() { server.sendHeader("Location", "/"); server.send(302, "text/plain", ""); }

void wifiStart() {
  if (wifiUp) return;
  WiFi.mode(WIFI_AP);
  WiFi.softAP(apSsid.c_str(), strlen(AP_PASS) >= 8 ? AP_PASS : nullptr);
  server.begin();
  wifiUp = true;
  Serial.printf("Wi-Fi 熱點 %s  密碼 %s  配對碼 %s  網址 http://%s/\n", apSsid.c_str(), AP_PASS, pairCode, WiFi.softAPIP().toString().c_str());
}
void wifiStop() {
  if (!wifiUp) return;
  server.stop();
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_OFF);
  wifiUp = false;
  kickPhone();
}

// ======================== 位元組計算 ========================
uint8_t fnBits(int f, int dir) {
  bool fwd = dir > 0;
  if (S.rev & (1 << f)) fwd = !fwd;
  return fwd ? PORT_F[S.map[f]] : PORT_B[S.map[f]];
}
uint8_t dirBits(int f, int kPos, int kNeg) {
  if (isDown(kPos) && !isDown(kNeg)) return fnBits(f, 1);
  if (isDown(kNeg) && !isDown(kPos)) return fnBits(f, -1);
  return 0;
}
int mtSel = 0;
uint8_t computeTx() {
  if (!linked) return 0;
  if (screen == SC_MTEST) {
    if (isDown(K_RU) || isDown(K_B)) return PORT_F[mtSel];
    if (isDown(K_RL)) return PORT_B[mtSel];
    return 0;
  }
  if (screen != SC_DRIVE) return 0;            // 選單裡一律停車
  uint8_t b = 0;
  if (S.src != SRC_PHONE) {                     // 實體鍵
    b = dirBits(F_L, K_LU, K_LD) | dirBits(F_R, K_RU, K_RD) | dirBits(F_DOOR, K_RR, K_RL);
    uint8_t br = dirBits(F_BRUSH, K_LL, K_LR);
    if (!br && latch && !isDown(K_LL) && !isDown(K_LR)) br = fnBits(F_BRUSH, 1);
    b |= br;
  }
  if (S.src != SRC_PHYS && phoneFresh()) {      // 手機（套用同一套馬達對應與反轉）
    const uint8_t pos[4] = { 1, 4, 16, 64 }, neg[4] = { 2, 8, 32, 128 };
    for (int f = 0; f < 4; f++) {
      bool a = phoneBits & pos[f], c = phoneBits & neg[f];
      if (a && !c) b |= fnBits(f, 1); else if (c && !a) b |= fnBits(f, -1);
    }
  }
  for (int i = 0; i < 4; i++)                   // 同一顆馬達正反同時 → 取消
    if ((b & PORT_F[i]) && (b & PORT_B[i])) b &= ~(PORT_F[i] | PORT_B[i]);
  return b;
}

// ======================== 選單 ========================

const Item MENU_ROOT[] = { { "連線", SUB, M_CONN }, { "手機連線", SUB, M_PHONE }, { "馬達設定", SUB, M_MOTOR },
  { "按鍵測試", ACT, C_KEYTEST }, { "螢幕與比賽", SUB, M_DISP }, { "目標裝置", SUB, M_TARGET }, { "關於", SUB, M_ABOUT } };
const Item MENU_PHONE[] = { { "顯示 QR Code", ACT, C_PQR }, { "配對碼", INFO, C_CODE }, { "操作來源", ACT, C_SRC },
  { "換碼踢掉手機", ACT, C_KICK }, { "Wi-Fi 熱點", ACT, C_WIFI } };
const Item MENU_CONN[] = { { "選擇小車", ACT, C_SCAN }, { "重新連線", ACT, C_RECONN }, { "忘記這台", ACT, C_FORGET }, { "目前", INFO, C_CUR } };
const Item MENU_MOTOR[] = { { "左輪 接", ACT, C_MAP0 }, { "右輪 接", ACT, C_MAP1 }, { "滾刷 接", ACT, C_MAP2 }, { "後門 接", ACT, C_MAP3 },
  { "左輪反轉", ACT, C_REV0 }, { "右輪反轉", ACT, C_REV1 }, { "滾刷反轉", ACT, C_REV2 }, { "後門反轉", ACT, C_REV3 },
  { "單顆馬達測試", ACT, C_MTEST }, { "恢復預設", ACT, C_RESET } };
const Item MENU_DISP[] = { { "亮度", ACT, C_BRIGHT }, { "比賽鎖定", ACT, C_LOCK } };
const Item MENU_TARGET[] = { { "清道達人", ACT, C_PT }, { "無人機（開發中）", OFF, C_NONE } };
const Item MENU_ABOUT[] = { { "版本", INFO, C_VER }, { "板子", INFO, C_BOARD }, { "網站 QR", ACT, C_QR } };

const MenuDef MENUS[] = {
  { "設定選單", MENU_ROOT, 7 }, { "連線", MENU_CONN, 4 }, { "馬達設定", MENU_MOTOR, 10 },
  { "螢幕與比賽", MENU_DISP, 2 }, { "目標裝置", MENU_TARGET, 2 }, { "關於", MENU_ABOUT, 3 },
  { "手機連線", MENU_PHONE, 5 } };

Level stack[6]; int depth = 0;
const int ROWS = 4;
int scanIdx = 0, scanTop = 0;
int qrPage = 0;

String rightText(const Item &it, uint16_t &col) {
  col = C_DIM;
  if (it.kind == SUB) return "›";
  if (it.kind == OFF) return "開發中";
  char b[24];
  switch (it.arg) {
    case C_CUR: return linked ? S.name : String("未連線");
    case C_MAP0: case C_MAP1: case C_MAP2: case C_MAP3:
      snprintf(b, sizeof b, "M%d", S.map[it.arg - C_MAP0] + 1); return b;
    case C_REV0: case C_REV1: case C_REV2: case C_REV3: {
      bool on = S.rev & (1 << (it.arg - C_REV0)); col = on ? C_OK : C_DIM; return on ? "開" : "關"; }
    case C_BRIGHT: snprintf(b, sizeof b, "%d%%", S.bright); return b;
    case C_LOCK: col = S.lock ? C_OK : C_DIM; return S.lock ? "開" : "關";
    case C_PT: col = C_OK; return "●";
    case C_VER: return FW_VERSION;
    case C_BOARD: return BOARD_NAME;
    case C_WIFI: col = S.wifi ? C_OK : C_DIM; return S.wifi ? "開" : "關";
    case C_CODE: return S.wifi ? String(pairCode) : String("-");
    case C_SRC: return S.src == SRC_MIX ? "混合" : S.src == SRC_PHYS ? "實體鍵" : "手機";
    case C_KICK: col = phoneActive() ? C_OK : C_DIM; return phoneActive() ? "控制中" : "";
    case C_PQR: return "›";
  }
  return "";
}

void drawRows(const char *title, const char *crumb, int n, int idx, int top,
              const char *(*label)(int), String (*right)(int, uint16_t &), bool (*dim)(int)) {
  tft.fillScreen(C_BG);
  header(title, crumb);
  int rowH = (H - HB) / ROWS;
  for (int r = 0; r < ROWS; r++) {
    int i = top + r; if (i >= n) break;
    int y = HB + r * rowH;
    bool sel = i == idx;
    uint16_t bg = sel ? C_SEL : C_BG;
    if (sel) { tft.fillRoundRect(2, y + 1, W - 8, rowH - 2, 4, bg); tft.fillRect(2, y + 1, 3, rowH - 2, C_ACC); }
    int ty = y + (rowH - 17) / 2;
    text(font16, label(i), 11, ty, dim(i) ? C_DIM : (sel ? C_ACC : C_FG), bg);
    uint16_t rc; String rt = right(i, rc);
    if (sel && rc == C_DIM) rc = C_ACC;
    text(font14, rt.c_str(), W - 10, ty + 1, rc, bg, 2);
  }
  if (n > ROWS) {                                    // 捲軸
    int track = H - HB - 4, bh = track * ROWS / n, by = HB + 2 + track * top / n;
    tft.fillRect(W - 3, HB + 2, 2, track, C_BOX);
    tft.fillRect(W - 3, by, 2, bh, C_DIM);
  }
}

const MenuDef &curMenu() { return MENUS[stack[depth - 1].id]; }
const char *menuLabel(int i) { return curMenu().items[i].label; }
String menuRight(int i, uint16_t &c) { return rightText(curMenu().items[i], c); }
bool menuDim(int i) { const Item &it = curMenu().items[i]; return it.kind == OFF || it.kind == INFO; }
void drawMenu() {
  Level &L = stack[depth - 1];
  if (L.idx < L.top) L.top = L.idx;
  if (L.idx >= L.top + ROWS) L.top = L.idx - ROWS + 1;
  drawRows(curMenu().title, depth > 1 ? MENUS[stack[depth - 2].id].title : "", curMenu().n, L.idx, L.top, menuLabel, menuRight, menuDim);
}

const char *scanLabel(int i) { return cars[i].name.c_str(); }
String scanRight(int i, uint16_t &c) { c = cars[i].mac == S.mac && linked ? C_OK : C_DIM; return String(cars[i].rssi); }
bool scanDim(int i) { return false; }
void drawScan() {
  if (cars.empty()) {
    tft.fillScreen(C_BG); header("選擇小車", "0");
    text(font16, "沒有找到小車", W / 2, H / 2 - 20, C_BAD, C_BG, 1);
    text(font14, "右▲ 重新掃描　右▼ 返回", W / 2, H / 2 + 8, C_DIM, C_BG, 1);
    return;
  }
  if (scanIdx < scanTop) scanTop = scanIdx;
  if (scanIdx >= scanTop + ROWS) scanTop = scanIdx - ROWS + 1;
  drawRows("選擇小車", "訊號", cars.size(), scanIdx, scanTop, scanLabel, scanRight, scanDim);
}

void cycleMap(int f) {
  int next = (S.map[f] + 1) % 4;
  for (int o = 0; o < 4; o++) if (o != f && S.map[o] == next) {
    S.map[o] = S.map[f];                          // 對應不重複：被搶走的功能換到空出來的埠
    S.map[f] = next; saveSettings(); needFull = true;
    toast(String(FNNAME[o]) + " 換到 M" + (S.map[o] + 1));
    return;
  }
  S.map[f] = next; saveSettings();
}

void go(Screen s) { screen = s; needFull = true; }
void enterMenu() { depth = 1; stack[0] = { M_ROOT, 0, 0 }; go(SC_MENU); Serial.println("進入選單（送出 00）"); }
void back() {
  if (screen == SC_MENU) { if (depth > 1) { depth--; needFull = true; } else go(SC_DRIVE); return; }
  if (screen == SC_SCAN || screen == SC_TEST || screen == SC_MTEST || screen == SC_QR || screen == SC_PQR) go(SC_MENU);
}
void startScan() {
  busy("掃描中…", "約 3 秒");
  scanCars(3);
  scanIdx = 0; scanTop = 0;
  for (int i = 0; i < (int)cars.size(); i++) if (cars[i].mac == S.mac) scanIdx = i;
  go(SC_SCAN);
}
void doAction(uint8_t code) {
  switch (code) {
    case C_SCAN: startScan(); return;
    case C_RECONN: retries = 0; if (reconnectSaved()) toast("已連線"); else toast("找不到這台車"); needFull = true; return;
    case C_FORGET: if (linked) client->disconnect(); S.mac = ""; S.name = ""; saveSettings(); toast("已忘記"); needFull = true; return;
    case C_MAP0: case C_MAP1: case C_MAP2: case C_MAP3: cycleMap(code - C_MAP0); break;
    case C_REV0: case C_REV1: case C_REV2: case C_REV3: S.rev ^= 1 << (code - C_REV0); saveSettings(); break;
    case C_MTEST: mtSel = 0; go(SC_MTEST); return;
    case C_RESET: { Settings d; memcpy(S.map, d.map, 4); S.rev = 0; saveSettings(); toast("已恢復預設"); needFull = true; return; }
    case C_BRIGHT: S.bright = S.bright >= 100 ? 25 : S.bright + 25; setBright(S.bright); saveSettings(); break;
    case C_LOCK: S.lock = !S.lock; saveSettings(); if (S.lock) { go(SC_DRIVE); toast("已鎖定：選單鍵失效"); return; } break;
    case C_KEYTEST: go(SC_TEST); return;
    case C_QR: go(SC_QR); return;
    case C_WIFI: S.wifi = !S.wifi; saveSettings(); if (S.wifi) wifiStart(); else wifiStop(); break;
    case C_SRC: S.src = S.src == SRC_MIX ? SRC_PHYS : S.src == SRC_PHYS ? SRC_PHONE : SRC_MIX; saveSettings();
                if (S.src == SRC_PHYS) kickPhone(); break;
    case C_KICK: newPairCode(); kickPhone(); toast(String("新配對碼 ") + pairCode); needFull = true; return;
    case C_PQR: if (!S.wifi) { toast("先開 Wi-Fi 熱點"); return; } qrPage = 0; go(SC_PQR); return;
    default: return;
  }
  needFull = true;
}
void confirmSel() {
  if (screen == SC_PQR) { qrPage ^= 1; needFull = true; return; }
  if (screen == SC_SCAN) {
    if (cars.empty()) { startScan(); return; }
    if (connectCar(cars[scanIdx])) { retries = 0; go(SC_DRIVE); toast("已連線"); }
    else { go(SC_SCAN); toast("連線失敗"); }
    return;
  }
  if (screen != SC_MENU) return;
  const Item &it = curMenu().items[stack[depth - 1].idx];
  if (it.kind == OFF) { toast("還在開發"); return; }
  if (it.kind == INFO) return;
  if (it.kind == SUB) { stack[depth++] = { it.arg, 0, 0 }; needFull = true; return; }
  doAction(it.arg);
}
void moveSel(int d) {
  if (screen == SC_MENU) { Level &L = stack[depth - 1]; int n = curMenu().n; L.idx = (L.idx + d + n) % n; needFull = true; }
  else if (screen == SC_SCAN && !cars.empty()) { int n = cars.size(); scanIdx = (scanIdx + d + n) % n; needFull = true; }
  else if (screen == SC_MTEST) { mtSel = (mtSel + d + 4) % 4; needFull = true; }
  else if (screen == SC_PQR) { qrPage ^= 1; needFull = true; }
}

// ======================== 按鍵事件 ========================
bool listScreen() { return screen == SC_MENU || screen == SC_SCAN || screen == SC_QR || screen == SC_PQR; }
void onPress(int k) {
  if (screen == SC_BOOT) return;
  if (screen == SC_TEST) { needFull = true; return; }
  if (screen == SC_DRIVE) {
    if (k == K_LATCH) latch = !latch;
    if (k == K_RU && !linked && S.mac != "") { retries = 0; nextRetry = 0; }
    return;
  }
  if (screen == SC_MTEST) {
    if (k == K_LU) moveSel(-1); else if (k == K_LD) moveSel(1); else if (k == K_RD) back();
    else needFull = true;
    return;
  }
  if (listScreen()) {
    if (k == K_LU) moveSel(-1); else if (k == K_LD) moveSel(1);
    else if (k == K_RU) confirmSel(); else if (k == K_RD) back();
    else if (k == K_A) moveSel(1);
  }
}
void onRelease(int k, uint32_t dur, bool used) {
  if (screen == SC_TEST) { needFull = true; return; }
  if (screen == SC_MTEST) { needFull = true; if (k == K_A && !used) moveSel(1); return; }
  if (used) return;
  if (listScreen()) {
    if (k == K_B && dur < 600) confirmSel();
    if (k == K_MENU) go(SC_DRIVE);
  }
  if (screen == SC_DRIVE && k == K_B && !linked && S.mac != "") { retries = 0; nextRetry = 0; }
}
void holdChecks() {
  uint32_t now = millis();
  if (screen == SC_DRIVE) {
    for (int k : { K_MENU, K_B }) if (isDown(k) && !btn[k].used && heldMs(k) >= 1000 && !(isDown(K_A) && isDown(K_B))) {
      btn[k].used = true;
      if (S.lock) toast("比賽鎖定中"); else enterMenu();
    }
    if (isDown(K_A) && isDown(K_B) && !btn[K_A].used && heldMs(K_A) >= 3000 && heldMs(K_B) >= 3000) {
      btn[K_A].used = btn[K_B].used = true;
      if (S.lock) { S.lock = false; saveSettings(); needFull = true; toast("已解鎖"); }
    }
  }
  if (listScreen() && isDown(K_B) && !btn[K_B].used && heldMs(K_B) >= 600) { btn[K_B].used = true; back(); }
  if (screen == SC_TEST) for (int k : { K_RD, K_B }) if (isDown(k) && !btn[k].used && heldMs(k) >= 2000) { btn[k].used = true; back(); }
  if (screen == SC_MTEST && isDown(K_A) && !btn[K_A].used && heldMs(K_A) >= 800) { btn[K_A].used = true; back(); }
  (void)now;
}

// ======================== 畫面 ========================
uint8_t shownTx = 0xFF; bool shownLinked = false, shownLatch = false; int shownBar = -1;
// 底部提示的狀態：0 一般　1 顯示配對碼　2 手機控制中　3 手機訊號中斷
int phoneState() {
  if (!S.wifi || S.src == SRC_PHYS) return 0;
  if (!phoneActive()) return 1;
  return phoneFresh() ? 2 : 3;
}

void triangle(int cx, int cy, int s, bool up, uint16_t c) {
  if (up) tft.fillTriangle(cx, cy - s, cx - s, cy + s / 2, cx + s, cy + s / 2, c);
  else    tft.fillTriangle(cx, cy + s, cx - s, cy - s / 2, cx + s, cy - s / 2, c);
}
void drawDriveDyn(bool force) {
  uint8_t b = txNow;
  if (!force && b == shownTx && linked == shownLinked && latch == shownLatch) return;
  shownTx = b; shownLinked = linked; shownLatch = latch;
  int col = W / 6, s = H / 9;
  int yU = HB + (H - HB) * 30 / 100, yD = HB + (H - HB) * 70 / 100;
  bool lF = linked && (b & fnBits(F_L, 1)), lB = linked && (b & fnBits(F_L, -1));
  bool rF = linked && (b & fnBits(F_R, 1)), rB = linked && (b & fnBits(F_R, -1));
  triangle(col / 2 + 2, yU, s, true, lF ? C_ACC : C_BOX);
  triangle(col / 2 + 2, yD, s, false, lB ? C_ACC : C_BOX);
  triangle(W - col / 2 - 2, yU, s, true, rF ? C_ACC : C_BOX);
  triangle(W - col / 2 - 2, yD, s, false, rB ? C_ACC : C_BOX);
  int x0 = col + 4, x1 = W - col - 4, cw = x1 - x0;
  int rowH = (H - HB - 20) / 3, y = HB + 4;
  if (!linked) {
    tft.fillRect(x0, HB + 1, cw, H - HB - 20, C_BG);
    text(font20, connecting ? "連線中…" : "未連線", W / 2, HB + 10, connecting ? C_ACC : C_BAD, C_BG, 1);
    text(font14, S.mac == "" ? "長按選單 → 連線" : "按 右▲ 重新連線", W / 2, HB + 42, C_DIM, C_BG, 1);
    return;
  }
  bool bin = b & fnBits(F_BRUSH, 1), bout = b & fnBits(F_BRUSH, -1);
  bool du = b & fnBits(F_DOOR, 1), dd = b & fnBits(F_DOOR, -1);
  const char *bs = bin ? (latch && !isDown(K_LL) ? "收球 常開" : "收球") : bout ? "吐球" : "停";
  const char *ds = du ? "開＋" : dd ? "關−" : "停";
  for (int r = 0; r < 2; r++) {
    int yy = y + r * rowH;
    tft.fillRoundRect(x0, yy, cw, rowH - 4, 5, C_BOX);
    text(font14, r == 0 ? "滾刷" : "後門", x0 + 6, yy + (rowH - 4 - 15) / 2, C_DIM, C_BOX);
    bool on = r == 0 ? (bin || bout) : (du || dd);
    text(font20, r == 0 ? bs : ds, x1 - 6, yy + (rowH - 4 - 21) / 2, on ? C_ACC : C_FG, C_BOX, 2);
  }
  int yy = y + 2 * rowH;
  tft.fillRect(x0, yy, cw, rowH - 4, C_BG);
  char hx[12]; snprintf(hx, sizeof hx, "TX 0x%02X", b);
  text(font12, hx, W / 2, yy + 2, b ? C_ACC : C_DIM, C_BG, 1);
}
void drawDriveBar() {      // 底部：長按進度或提示
  int p = -1;
  if (isDown(K_MENU) && !btn[K_MENU].used) p = heldMs(K_MENU) / 10;
  else if (isDown(K_B) && !btn[K_B].used && !isDown(K_A)) p = heldMs(K_B) / 10;
  else if (isDown(K_A) && isDown(K_B) && S.lock) p = (heldMs(K_A) < heldMs(K_B) ? heldMs(K_A) : heldMs(K_B)) / 30;
  if (p > 100) p = 100;
  if (p > 0) p = p / 5 * 5;                         // 每 5% 更新一次，減少閃爍
  int key = p >= 0 ? p : -10 - phoneState();
  if (key == shownBar) return;
  int y = H - 18;
  tft.fillRect(0, y, W, 18, C_BG);
  if (p < 0) {
    int ps = phoneState();
    if (S.lock) text(font14, "比賽鎖定中", W / 2, y + 1, C_BAD, C_BG, 1);
    else if (ps == 1) {
      text(font14, "手機配對碼", W / 2 - 4, y + 1, C_DIM, C_BG, 2);
      text(font16, pairCode, W / 2 + 4, y, C_ACC, C_BG, 0);
    }
    else if (ps == 2) text(font14, "手機控制中", W / 2, y + 1, C_OK, C_BG, 1);
    else if (ps == 3) text(font14, "手機訊號中斷", W / 2, y + 1, C_BAD, C_BG, 1);
    else text(font14, "長按選單 1 秒：設定", W / 2, y + 1, C_DIM, C_BG, 1);
  } else {
    tft.fillRect(0, H - 4, W * p / 100, 4, S.lock ? C_BAD : C_ACC);
    text(font14, S.lock ? (isDown(K_A) ? "解鎖中…" : "比賽鎖定中") : "放開取消", W / 2, y - 1, S.lock ? C_BAD : C_ACC, C_BG, 1);
  }
  shownBar = key;
}
void drawDriveFull() {
  tft.fillScreen(C_BG);
  header("清道達人", linked ? S.name.c_str() : (connecting ? "連線中" : "未連線"), linked ? C_FG : C_BAD);
  shownBar = -2;
  drawDriveDyn(true);
  drawDriveBar();
}

void drawTest() {
  tft.fillScreen(C_BG);
  header("按鍵測試", "長按右▼離開");
  int cols = 4, cw = (W - 8) / cols, ch = (H - HB - 6) / 3;
  for (int k = 0; k < NKEY; k++) {
    int x = 4 + (k % cols) * cw, y = HB + 3 + (k / cols) * ch;
    bool on = isDown(k);
    uint16_t bg = on ? C_ACC : C_BOX;
    tft.fillRoundRect(x + 1, y + 1, cw - 2, ch - 2, 4, bg);
    text(font14, KEYNAME[k], x + cw / 2, y + 2, on ? TFT_BLACK : C_FG, bg, 1);
    char g[8]; snprintf(g, sizeof g, "%d", PINS[k]);
    text(font12, g, x + cw / 2, y + ch - 15, on ? TFT_BLACK : C_DIM, bg, 1);
  }
}
void drawMtest() {
  tft.fillScreen(C_BG);
  header("單顆馬達測試", linked ? "" : "未連線", C_BAD);
  int cw = (W - 8) / 4, top = HB + 6, ch = (H - HB) * 55 / 100;
  bool run = isDown(K_RU) || isDown(K_B) || isDown(K_RL);
  for (int i = 0; i < 4; i++) {
    int x = 4 + i * cw; bool sel = i == mtSel;
    uint16_t bg = sel ? C_SEL : C_BOX;
    tft.fillRoundRect(x + 2, top, cw - 4, ch, 6, bg);
    if (sel) tft.drawRoundRect(x + 2, top, cw - 4, ch, 6, C_ACC);
    char m[4]; snprintf(m, sizeof m, "M%d", i + 1);
    text(font20, m, x + cw / 2, top + 6, sel ? C_ACC : C_FG, bg, 1);
    String who; for (int f = 0; f < 4; f++) if (S.map[f] == i) who += FNNAME[f];
    text(font14, who == "" ? "-" : who.c_str(), x + cw / 2, top + ch - 22, C_DIM, bg, 1);
  }
  const char *msg = !linked ? "先到「連線」選小車" : run ? (isDown(K_RL) ? "反轉中" : "正轉中") : "按住 右▲ 正轉　門− 反轉";
  text(font14, msg, W / 2, H - 19, run ? C_ACC : C_DIM, C_BG, 1);
}
// 畫 QR Code：回傳實際邊長（像素），失敗回傳 0
int drawQRCode(const char *txt, int x0, int y0, int maxPx) {
  static uint8_t qr[qrcodegen_BUFFER_LEN_FOR_VERSION(8)], tmp[qrcodegen_BUFFER_LEN_FOR_VERSION(8)];
  if (!qrcodegen_encodeText(txt, tmp, qr, qrcodegen_Ecc_LOW, 1, 8, qrcodegen_Mask_AUTO, true)) return 0;
  int n = qrcodegen_getSize(qr), cell = maxPx / (n + 4), size = (n + 4) * cell;
  if (cell < 1) return 0;
  tft.fillRect(x0, y0, size, size, TFT_WHITE);        // 白底＝安靜區（2 格）
  for (int r = 0; r < n; r++)
    for (int c = 0; c < n; c++)
      if (qrcodegen_getModule(qr, c, r)) tft.fillRect(x0 + (c + 2) * cell, y0 + (r + 2) * cell, cell, cell, TFT_BLACK);
  return size;
}
void drawQR() {
  tft.fillScreen(C_BG);
  header("PowerTech 工具箱");
  int maxPx = H - HB - 18;
  int s = drawQRCode(SITE_URL, (W - maxPx) / 2, HB + 3, maxPx);
  (void)s;
  text(font12, "zhengxuetech.github.io/powertech", W / 2, H - 13, C_DIM, C_BG, 1);
}
void drawPhoneQR() {
  tft.fillScreen(C_BG);
  header("手機連線", qrPage == 0 ? "1/2" : "2/2");
  int maxPx = H - HB - 6;
  String txt;
  if (qrPage == 0) {
    txt = String("WIFI:T:") + (strlen(AP_PASS) >= 8 ? "WPA" : "nopass") + ";S:" + apSsid + ";P:" + AP_PASS + ";;";
  } else {
    txt = String("http://") + WiFi.softAPIP().toString() + "/";
  }
  int s = drawQRCode(txt.c_str(), 4, HB + 3, maxPx);
  int x = s + 12, y = HB + 4;
  if (qrPage == 0) {
    text(font14, "① 掃描連 Wi-Fi", x, y, C_ACC);
    text(font12, apSsid.c_str(), x, y + 20, C_FG);
    text(font12, strlen(AP_PASS) >= 8 ? AP_PASS : "(no password)", x, y + 35, C_DIM);
  } else {
    text(font14, "② 開控制頁", x, y, C_ACC);
    text(font12, WiFi.softAPIP().toString().c_str(), x, y + 20, C_FG);
    text(font14, "瀏覽器輸入也可", x, y + 35, C_DIM);
  }
  text(font14, "配對碼", x, y + 58, C_DIM);
  text(font24, pairCode, x, y + 76, C_ACC);
}
void drawBoot() {
  tft.fillScreen(C_BG);
  text(font24, "學思創客", W / 2, H / 2 - 40, C_FG, C_BG, 1);
  text(font20, "萬用遙控器", W / 2, H / 2 - 8, C_ACC, C_BG, 1);
  text(font12, FW_VERSION "  " BOARD_NAME, W / 2, H / 2 + 24, C_DIM, C_BG, 1);
}

void render() {
  if (toastUntil && millis() > toastUntil) { toastUntil = 0; needFull = true; }
  if (needFull) {
    needFull = false;
    switch (screen) {
      case SC_BOOT: drawBoot(); break;
      case SC_DRIVE: drawDriveFull(); break;
      case SC_MENU: drawMenu(); break;
      case SC_SCAN: drawScan(); break;
      case SC_TEST: drawTest(); break;
      case SC_MTEST: drawMtest(); break;
      case SC_QR: drawQR(); break;
      case SC_PQR: drawPhoneQR(); break;
    }
    if (toastUntil) drawToast();
    return;
  }
  if (screen == SC_DRIVE && !toastUntil) { drawDriveDyn(false); drawDriveBar(); }
}

// ======================== 主程式 ========================
void setup() {
  Serial.begin(115200);
#ifdef PIN_POWER_ON
  pinMode(PIN_POWER_ON, OUTPUT); digitalWrite(PIN_POWER_ON, HIGH);
#endif
  for (int k = 0; k < NKEY; k++) if (PINS[k] >= 0) pinMode(PINS[k], (PINS[k] >= 34 && PINS[k] <= 39) ? INPUT : INPUT_PULLUP);
  prefs.begin("uniremote", false);
  loadSettings();
  tft.init();
  tft.setRotation(1);
  // 背光 PWM 要在 tft.init() 之後接上（init 會把背光腳設回一般輸出）
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(PIN_BL, 5000, 8);
#else
  ledcSetup(0, 5000, 8); ledcAttachPin(PIN_BL, 0);
#endif
  W = tft.width(); H = tft.height(); HB = H >= 160 ? 24 : 20;
  setBright(S.bright);
  drawBoot();

  BLEDevice::init("PT-Remote");
  client = BLEDevice::createClient();
  client->setClientCallbacks(new ClientCB());

  // Wi-Fi 熱點：名稱用晶片序號，教室裡多台遙控器不會撞名
  char ssid[24];
  snprintf(ssid, sizeof ssid, "PowerTech-%04X", (unsigned)((ESP.getEfuseMac() >> 32) & 0xFFFF));
  apSsid = ssid;
  newPairCode();
  server.on("/", hPage);
  server.on("/s", hStatus);
  server.on("/pair", hPair);
  server.on("/c", hCtl);
  server.onNotFound(hOther);
  if (S.wifi) wifiStart();
  delay(500);
  if (S.mac != "") { connecting = true; reconnectSaved(); connecting = false; retries = 1; nextRetry = millis() + 1500; }
  go(SC_DRIVE);
}

void loop() {
  pollKeys();
  holdChecks();
  if (wifiUp) server.handleClient();

  // 斷線自動重連：最多 3 次，之後按 右▲ 再試
  if (screen == SC_DRIVE && !linked && S.mac != "" && retries < 3 && millis() > nextRetry) {
    connecting = true; needFull = true; render();
    reconnectSaved();
    connecting = false; retries++; nextRetry = millis() + 1500; needFull = true;
    if (linked) retries = 0;
  }

  static uint32_t lastTx = 0;
  if (millis() - lastTx >= TX_MS) {
    lastTx = millis();
    uint8_t b = computeTx();
    static uint8_t lastPrinted = 0xFF;
    if (b != lastPrinted) { Serial.printf("TX %02X\n", b); lastPrinted = b; }
    txNow = b;
    if (linked && chr) chr->writeValue(&b, 1, false);
    if (screen == SC_MTEST) { static uint8_t lastMt = 0xFF; if (b != lastMt) { lastMt = b; needFull = true; } }
  }
  static bool wasLinked = false;
  if (linked != wasLinked) { wasLinked = linked; needFull = true; if (!linked) Serial.println("斷線"); }
  render();
  delay(2);
}

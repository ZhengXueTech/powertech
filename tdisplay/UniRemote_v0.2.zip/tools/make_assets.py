"""產生 assets.h：TFT_eSPI 平滑字型（只收韌體用到的字）。
用法：python3 make_assets.py ../UniRemote"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_vlw as M

def main(d):
    ino = open(os.path.join(d, "UniRemote.ino"), encoding="utf-8").read()
    chars = set(M.ASCII)
    for lit in re.findall(r'"((?:[^"\\]|\\.)*)"', ino):
        chars |= set(lit)
    chars |= set("›")
    cjk = sorted(c for c in chars if c >= " ")
    M.charset = lambda: cjk
    parts = ["// 自動產生，請勿手改：python3 tools/make_assets.py UniRemote\n"
             "// 字型：Noto Sans CJK TC（SIL Open Font License 1.1）子集\n#pragma once\n#include <pgmspace.h>\n"]
    total = 0
    for s in [12, 14, 16, 20, 24]:
        if s == 12:
            M.charset = lambda: sorted(set(M.ASCII) | set("›"))
        else:
            M.charset = lambda: cjk
        data, n = M.build(s)
        parts.append(M.to_c(f"font{s}", data)); total += len(data)
        print(f"font{s}: {n} glyphs, {len(data)} bytes")
    open(os.path.join(d, "assets.h"), "w").write("\n".join(parts))
    print("total font bytes", total)
main(sys.argv[1])

"""把 Noto Sans CJK TC 轉成 TFT_eSPI 平滑字型（.vlw 格式）陣列，只收需要的字。
用法：python3 make_vlw.py <輸出資料夾>
同時產生「點陣版」（無灰階，像 u8g2）方便比較。"""
import sys, os
from PIL import ImageFont, Image, ImageDraw

FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Medium.ttc"
TTC_INDEX = 3            # 0 JP / 1 KR / 2 SC / 3 TC / 4 HK
SIZES = [12, 14, 16, 20, 24]

SAMPLES = [
    "選擇小車 馬達反轉 比賽鎖定",
    "觸控鎖定 機器 優先權 斷線",
    "設定選單 目標裝置 連線 操作來源 手機連線 馬達設定 按鍵測試 螢幕與比賽 關於",
    "清道達人 無人機 開發中 重新連線 忘記這台 目前 實體按鍵 手機 混合",
    "熱點 配對碼 換 踢掉 顯示 亮度 閒置休眠 不休眠 分 版本 網站",
    "左輪 右輪 滾刷 後門 收球 吐球 常開 停 已連線 未連線 連線中 放開取消",
    "字級 平滑字型 點陣字型 按 BOOT 或 KEY 換頁 學思創客 萬用遙控器 正轉 反轉 單顆測試",
]
ASCII = "".join(chr(c) for c in range(0x20, 0x7F))


def charset():
    s = set(ASCII)
    for t in SAMPLES:
        s |= set(t)
    s |= set("・›‹▲▼◀▶●○＋−✓")
    ino = os.path.join(os.path.dirname(os.path.abspath(__file__)), "TDisplay_FontTest", "TDisplay_FontTest.ino")
    if os.path.exists(ino):
        import re
        for lit in re.findall(r'"([^"\\]*)"', open(ino, encoding="utf-8").read()):
            s |= set(lit)
    return sorted(c for c in s if c >= " ")


def i32(v):
    return int(v).to_bytes(4, "big", signed=True)


def build(size, bw=False):
    font = ImageFont.truetype(FONT, size, index=TTC_INDEX)
    glyphs, bitmaps = [], []
    asc, desc = font.getmetrics()
    for ch in charset():
        if ch == " ":
            # 空白：0×0 點陣，只要前進距離
            glyphs.append((ord(ch), 0, 0, round(font.getlength(ch)), 0, 0)); bitmaps.append(b""); continue
        l, t, r, b = font.getbbox(ch, anchor="ls")
        w, h = max(0, r - l), max(0, b - t)
        if w == 0 or h == 0:
            continue
        img = Image.new("L", (w, h), 0)
        ImageDraw.Draw(img).text((-l, -t), ch, font=font, fill=255, anchor="ls")
        data = img.tobytes()
        if bw:
            data = bytes(255 if p >= 110 else 0 for p in data)
        glyphs.append((ord(ch), h, w, round(font.getlength(ch)), -t, l))
        bitmaps.append(data)
    out = bytearray()
    out += i32(len(glyphs)) + i32(11) + i32(size) + i32(0) + i32(asc) + i32(desc)
    for u, h, w, adv, dy, dx in glyphs:
        out += i32(u) + i32(h) + i32(w) + i32(adv) + i32(dy) + i32(dx) + i32(0)
    for bmp in bitmaps:
        out += bmp
    name = b"NotoSansTC"
    out += bytes([len(name)]) + name + bytes([len(name)]) + name + b"\x00"
    return bytes(out), len(glyphs)


def to_c(name, data):
    lines = [f"const uint8_t {name}[] PROGMEM = {{"]
    for i in range(0, len(data), 24):
        lines.append("  " + ",".join(f"0x{b:02X}" for b in data[i:i + 24]) + ",")
    lines.append("};\n")
    return "\n".join(lines)


if __name__ == "__main__":
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    parts = ["// 自動產生：Noto Sans CJK TC（SIL OFL）子集，TFT_eSPI 平滑字型格式\n#pragma once\n#include <pgmspace.h>\n"]
    total = 0
    for s in SIZES:
        for bw in (False, True):
            data, n = build(s, bw)
            nm = f"font{s}" + ("_bw" if bw else "")
            parts.append(to_c(nm, data))
            total += len(data)
            print(nm, n, "glyphs", len(data), "bytes")
    open(os.path.join(out, "fonts.h"), "w").write("\n".join(parts))
    print("total", total)
